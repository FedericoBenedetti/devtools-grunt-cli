# gui-project-template

## Description

A template project for angular 1.x applications using [gui-common-angular](https://git.loccioni.com/IT/gui-common-angular)

## How to use

* Clone this project into a folder of your choice (*template-repo*)
* Create a new repository into another folder of your choice (*app-repo*)
* Copy content of the template-repo into the app-repo, excluding the .git folder
* Rename gui-project-template.sln into *\<app-name\>.sln*
* Edit file *app-repo\\.vs\\configuration\\applicationhost.config*
* Look for *sectionGroup name="authentication"* and change *overrideModeDefault* from *Deny* to *Allow*.

```
                    <section name="anonymousAuthentication" overrideModeDefault="Allow" />
                    <section name="basicAuthentication" overrideModeDefault="Allow" />
                    <section name="clientCertificateMappingAuthentication" overrideModeDefault="Allow" />
                    <section name="digestAuthentication" overrideModeDefault="Allow" />
                    <section name="iisClientCertificateMappingAuthentication" overrideModeDefault="Allow" />
                    <section name="windowsAuthentication" overrideModeDefault="Allow" />
 ```

 ## configuring the "Web" section of the project proprties page.

 * Right click the app project in the solution
 * Copy the content of "Project URL" field.
 * Paste what you copied in the Start URL (you must select it before)
 * Append "/src" to Start URL. Start URL should look like this:

` Start URL: http://localhost:51555/src `

while Proeject URL should be something like this.

` Project URL: http://localhost:51555/ `

 ## Directory layout

 ```
 solution-directory/
 + app/
   + src/           <-- Source files for the app
   | + app/
   | | + api/       <-- This will be filled by the api-generator tasks based on config
   | | |              of the swagger_codegen task.
   | | + config/    <-- Main configurations for the environment
   | | + ui/        <-- Pages, controllers and services... the app! 
   | |   + config/  <-- app related configurations, such as routing, translations, ...
   | + assets/      <-- Content that will be copied "as is" in the distribution folder
   |                    There are Grunt Task that will populate the asset directory 
   |                    to build necessary resources environment for gl-gui-common.
   + dist/          <-- Here you will get your application ready to be copied to 
                        production/test server.
 ```

 ## Adding files to the project

 To add a new js (ts) file to the solution, simply reference it int the right section of the 
 *index.html* file.

 Let's say you wrote a brand new controller and want to add it to the *index.html*. 
 
* Edit *index.html*
* Find this piece of code:

```
    <!-- build:js js/03-app.js -->
    <script type="text/javascript" src="app.js"></script>
    <script type="text/javascript" src="assets/js/gl-app-templates.js"></script>
    <script type="text/javascript" src="app/ui/config/config.route.js"></script>
    <script type="text/javascript" src="app/ui/config/config.translate.js"></script>
    <script type="text/javascript" src="app/ui/config/config.exceptionHandler.js"></script>
    <script type="text/javascript" src="app/ui/app-pages/sample-page/sample-page-controller.js"></script>
    <!-- endbuild -->
```

* Add a row to the end. The *usemin* grunt task, will preserve the ordering of the files as they appear here.

Remember: While developing, you will be using the "normal" index.html.
The index that will fall in the *dist* folder, will contain just one row that will look like this:

```
    <script src="js/03-app.d0a520a0.js"></script>
```

## Changelog

### 1.0.2 - 21/03/2017

* Added this changelog 
* Update README.md