﻿module.exports = function (grunt) {

    grunt.registerMultiTask('network-credential', '', function () {
        try {
            //var secrets = grunt.file.readJSON(this.data.file);
            var secretsFile = grunt.file.read(this.data.file);
            var secrets = JSON.parse(secretsFile.replace(/\\/g, '/').replace(/\//g, '\\\\'))
            if (!secrets.publish) 
                throw new Error('Error...secrets.publish not valid!!')           
            if (!secrets.publish.host)
                throw new Errorwarn('Error...secrets.publish.host not valid!!')
            if (!secrets.publish.dest)
                throw new Error('Error...secrets.publish.dest not valid!!')
            if (!secrets.publish.username)
                throw new Error('Error...secrets.publish.username not valid!!')
            if (!secrets.publish.password)
                throw new Error('Error...secrets.publish.password not valid!!')
        }
        catch (ex) {
            grunt.log.writeln(ex);
            grunt.log.writeln('Assenza del file ' + this.data.file);
            grunt.log.writeln('Almeno la prima volta occorre salvare le credenziali per la pubblicazione su cartella di rete');
            grunt.log.writeln('Per far questo, lanciare da riga di comando il seguente script:');
            grunt.log.writeln('>node node_modules\\grunt\\bin\\grunt prompt:' + this.target);
            grunt.fail.warn('Error...')
        }
        grunt.config.set('secrets', secrets)
    })

}