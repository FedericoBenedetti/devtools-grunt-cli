angular.module('app').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('app/ui/app-pages/sample-page/sample-page.html',
    "<div ng-controller=sample-page-controller><h1 class=\"jumbotron text-center\">Hello World!</h1></div>"
  );

}]);
