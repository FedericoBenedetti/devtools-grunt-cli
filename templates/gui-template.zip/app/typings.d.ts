﻿/// <reference path="node_modules/@IT/gl-gui-common/ts/gl-common-boot.d.ts" />
/// <reference path="node_modules/@IT/gl-gui-common/ts/gl-common-libraries.d.ts" />
/// <reference path="node_modules/@IT/gl-gui-common/ts/gl-common-modules.d.ts" />