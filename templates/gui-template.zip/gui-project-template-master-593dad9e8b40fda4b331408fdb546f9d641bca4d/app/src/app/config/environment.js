var guiBoot = guiBoot || {};
guiBoot["environment"] = {"guiCommonUrl":"assets/gl-gui-common","identityServiceUrl":"https://auth-test.loccioni.com/Loccioni.Autenticazione.Service","initialPath":"./"};
guiBoot["version"] = {"info":{"guiCommonVersion":"1.2.7","name":"gui-sample-project-test","version":"1.0.0","copyright":"Loccioni","core":"angular-1.5"}};