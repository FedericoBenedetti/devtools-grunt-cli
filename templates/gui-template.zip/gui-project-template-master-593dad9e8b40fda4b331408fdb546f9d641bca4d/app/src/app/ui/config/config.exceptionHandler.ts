﻿// Include in index.html so that app level exceptions are handled.
// Exclude from testRunner.html which should run exactly what it wants to run
namespace App.Application.Config {

    export class IExceptionHandlerConfig {
        appErrorPrefix: string; //Configure the exceptionHandler decorator
    };


    // Extend the $exceptionHandler service to also display a toast.
    function extendExceptionHandler(
        $delegate: ng.IExceptionHandlerService,
        config: IExceptionHandlerConfig,
        logger: App.Logger.ILoggerService
        )
    {
        var appErrorPrefix = config.appErrorPrefix;
        var logError = logger.getLogFn('app', 'error');
        return function (exception, cause) {
            $delegate(exception, cause);
            if (appErrorPrefix && exception.message && exception.message.indexOf(appErrorPrefix) === 0) { return; }

            var errorData = { exception: exception, cause: cause };
            var msg = appErrorPrefix + exception.message;
            logError(msg, errorData, true);
        };
    }

    // Configure by setting an optional string value for appErrorPrefix.
    // Accessible via config.appErrorPrefix (via config value).
    function exceptionHandlerConfigBlock($provide: ng.auto.IProvideService) {
        $provide.decorator('$exceptionHandler', ['$delegate', 'config', 'logger', extendExceptionHandler]);
    }

    angular
        .module('app')
        .config(['$provide', exceptionHandlerConfigBlock]);
}