﻿/// <binding BeforeBuild='ide-pre-build' />
// Useful resources:
//https://quickleft.com/blog/grunt-js-tips-tricks/
//http://www.html5rocks.com/en/tutorials/tooling/supercharging-your-gruntfile/

module.exports = function (grunt) {
    require('load-grunt-tasks')(grunt);
    grunt.loadNpmTasks('@IT/gl-grunt-swagger-codegen');
    //Carico i task custom dalla cartella tasks
    grunt.task.loadTasks('tasks');

    grunt.initConfig({
        pkg: grunt.file.readJSON('./package.json'),

        /**
         * distributionBuild: Conterrà il "pacchetto" distribuibile dell'applicazione
         */
        distributionBuild: 'dist',

        /**
         * developerBuild: Conterrà la stessa cosa presente nel pacchetto di distribuzione ma con la configurazione dello sviluppatore. 
         */
        developerBuild: 'build',

        /**
         * developmentSrc: E' la directory in cui sta lavorando lo sviluppatore. Deve essere possibile lanciare il progetto da questa directory
         */
        developmentSrc: 'src',

        /**
         * apiDestination: E' la directory che conterrà le API generate da swagger code gen
         */
        apiDestination: 'src/app/api',

        /**
         * appConfigDestination
         */
        appConfigDestination: 'src/app/config',

        /**
         * 
         */
        assetsDirectory: 'src/assets',

        /**
         * directory temporanea
         */
        tempDirectory: 'temp',

        /**
         * glGuiCommonSrc: Posizione sorgente del pacchetto gl-gui-common
         */
        glGuiCommonSrc: 'node_modules/@IT/gl-gui-common',

        /**
         * glGuiCommonDestination: Posizione di destinazione del pacchetto gl-gui-common
         */
        glGuiCommonDestination: '<%= assetsDirectory %>/gl-gui-common',

        secrets: { publish: { host: '', dest: '', username: '', password: '' } },

        gl_swagger_codegen: {
            scheda_commessa_test: {
                URL: 'http://localhost:58000/Ski/api/swagger/docs/v1',
                language: 'gl-typescript-angular',
                output: 'GeneratedCode/typescript',
                API: 'API.SchedaCommessa',
                envPath: 'SchedaCommessaServiceUrl',
                copy: {
                    source: './node_modules/@IT/gl-grunt-swagger-codegen/api-generator/GeneratedCode/typescript/API/gl-schedacommessa-module',
                    dest: '<%=apiDestination %>/gl-schedacommessa-module'
                }
            }
        },

        shell: {
            options: {
                stdout: true,
                stdin: false
            },
            npm_install: {
                command: 'npm install'
            },
            tsd_install: {
                command: 'tsd install'
            },
            net_use: {
                command: 'net use <%= secrets.publish.host %> /user:<%= secrets.publish.username %> <%= secrets.publish.password %> '
            },
            net_use_delete: {
                command: 'net use <%= secrets.publish.host %> /delete'
            },
            echo_net_use: {
                command: 'echo <%= secrets.publish.host.replace(/\\\\/g, "/") %><%= secrets.publish.dest.replace(/\\\\/g, "/") %>'
            }
        },
        /****************************************************************        
        Crea il file info.json con le informazioni del package.json
        NOTA: file temporaneo creato per produrre il file environment.js
        ****************************************************************/
        json_generator: {
            build: {
                dest: '<%= tempDirectory %>/version.json',
                options: {
                    info: {
                        "guiCommonVersion": "",
                        "name": "<%= pkg.name %>",
                        "version": "<%= pkg.version %>",
                        "copyright": "Loccioni",
                        "core": "angular-1.5"
                    }
                }
            }
        },
        /****************************************************************        
        json: consente di creare il file di configurazione ambiente (environment.js)
              a partire dai json di configurazione (es. dev.environment.json)
        ****************************************************************/
        json: {
            dev_environment: {
                options: {
                    namespace: 'guiBoot',
                    //includePath: true,
                    processName: function (filename) {
                        return filename.indexOf('.') > -1 ? filename.split('.')[1] : filename;
                    },
                    processContent: function (content) {
                        if (content.info) {
                            content.info.name = grunt.config.get('pkg').name + '-test'
                            content.info.version = grunt.config.get('pkg').version
                            content.info.guiCommonVersion = grunt.config.get('pkg').dependencies["@IT/gl-gui-common"]
                        }
                        return content;
                    }
                },
                src: ['<%= appConfigDestination %>/dev.environment.json', '<%= tempDirectory %>/version.json'],
                dest: '<%= appConfigDestination %>/environment.js'
            },
            test_environment: {
                options: {
                    namespace: 'guiBoot',
                    //includePath: true,
                    processName: function (filename) {
                        return filename.indexOf('.') > -1 ? filename.split('.')[1] : filename;
                    },
                    processContent: function (content) {
                        if (content.info) {
                            content.info.name = grunt.config.get('pkg').name + '-test'
                            content.info.version = grunt.config.get('pkg').version
                            content.info.guiCommonVersion = grunt.config.get('pkg').dependencies["@IT/gl-gui-common"]
                        }
                        return content;
                    }
                },
                src: ['<%= appConfigDestination %>/test.environment.json', '<%= tempDirectory %>/version.json'],
                dest: '<%= appConfigDestination %>/environment.js'
            },
            prod_environment: {
                options: {
                    namespace: 'guiBoot',
                    //includePath: true,
                    processName: function (filename) {
                        return filename.indexOf('.') > -1 ? filename.split('.')[1] : filename;
                    },
                    processContent: function (content) {
                        if (content.info) {
                            content.info.name = grunt.config.get('pkg').name
                            content.info.version = grunt.config.get('pkg').version
                            content.info.guiCommonVersion = grunt.config.get('pkg').dependencies["@IT/gl-gui-common"]
                        }
                        return content;
                    }
                },
                src: ['<%= appConfigDestination %>/prod.environment.json', '<%= tempDirectory %>/version.json'],
                dest: '<%= appConfigDestination %>/environment.js'
            }
        },

        /****************************************************************        
        ngtemplates: consente di mettere in templateCache i template di
                     direttivae e view.
        ****************************************************************/
        ngtemplates: {
            glTemplates: {
                cwd: '<%= developmentSrc %>',
                src: ['app/ui/**/**.html'],
                dest: '<%= assetsDirectory %>/js/gl-app-templates.js',
                options: {
                    module: 'app',
                    htmlmin: {
                        collapseBooleanAttributes: true,
                        collapseWhitespace: true,
                        removeAttributeQuotes: true,
                        removeComments: true, // Only if you don't use comment directives!
                        removeEmptyAttributes: true,
                        removeRedundantAttributes: true,
                        removeScriptTypeAttributes: false,
                        removeStyleLinkTypeAttributes: true
                    }
                }
            }
        },


        /****************************************************************        
        copy: consente di copiare i file necessari alla build e distribution
        ****************************************************************/
        copy: {
            'build-dist': {
                files: [
                    { // index
                        expand: true,
                        cwd: '<%= developmentSrc %>',
                        src: ['./index.html', './web.config'],
                        dest: '<%= distributionBuild %>'
                    },
                    { // fonts
                        expand: true,
                        cwd: './node_modules/@IT/gl-gui-common',
                        src: 'fonts/**/*',
                        dest: '<%= distributionBuild %>'
                    },
                    { // assets
                        expand: true,
                        cwd: '<%= developmentSrc %>',
                        src: 'assets/**/*',
                        dest: '<%= distributionBuild %>'
                    }
                ],
            },
            // Copia il contenuto degli assets di gui common in glGuiCommonDestination
            'gui-common-asset-to-src': {
                files: [
                    {
                        expand: true,
                        cwd: '<%= glGuiCommonSrc %>',
                        src: '**/*.{gif,png,jpg,jpeg,woff,woff2,svg}',
                        dest: '<%= glGuiCommonDestination %>'
                    }
                ]
            },
            publishTest: {
                files: [
                    {
                        expand: true,
                        cwd: './src/build',
                        src: '**',
                        dest: '<%= secrets.publish.host.replace(/\\\\/g, "/") %><%= secrets.publish.dest.replace(/\\\\/g, "/") %>',
                        flatten: false,
                        filter: 'isFile'
                    }
                ]
            },
            publishProd: {
                files: [
                    {
                        expand: true,
                        cwd: './src/build',
                        src: '**',
                        dest: '<%= secrets.publish.host.replace(/\\\\/g, "/") %><%= secrets.publish.dest.replace(/\\\\/g, "/") %>',
                        flatten: false,
                        filter: 'isFile'
                    }
                ]
            }
        },
        /****************************************************************        
        Svuota le cartelle build e dist.       
        ****************************************************************/
        clean: {
            'temp': ['<%= tempDirectory %>/**/*'],

            'dist': {
                src: ['<%= distributionBuild %>/**/*']
            },
            'gui-common-asset': {
                src: ['<%= glGuiCommonDestination %>/**/*']
            },

            deployPath: {
                expand: true,
                cwd: '<%= secrets.publish.host.replace(/\\\\/g, "/") %><%= secrets.publish.dest.replace(/\\\\/g, "/") %>',
                src: '**/*',
                options: {
                    force: true,
                }
            }
        },
        /****************************************************************        
       prompt: consente di chiedere all'utente le credenziali di rete
               per i task di pubblicazione.
       network-credential: apre la connessione con il folder di rete
                           per la pubblicazione dell'installer.
       ****************************************************************/
        prompt: {
            clean_deployPath: {
                options: {
                    questions: [
                        {
                            config: 'cleanConfirm',
                            type: 'input',
                            message: 'you are going to delete ' + '<%= secrets.publish.host.replace(/\\\\/g, "/") %><%= secrets.publish.dest.replace(/\\\\/g, "/") %>' + '\nIs this ok? ',
                            default: 'n'
                        }
                    ], then: function (results, done) {
                        console.log(results);
                        if (results.cleanConfirm != 'y') {
                            grunt.fail.fatal('User did not accept to clean deploy dir. Exiting!');
                        }
                    }
                },
            },
            test_credentials: {
                options: {
                    questions: [
                        {
                            config: 'host',
                            type: 'input',
                            message: 'network folder:',
                            default: '\\\\gl-webapp02\\E$'
                        },
                        {
                            config: 'dest',
                            type: 'input',
                            message: 'destination folder :',
                            default: '\\Web\\'
                        },
                        {
                            config: 'username',
                            type: 'input',
                            message: 'username:',
                            default: 'gl-webapp02\\administrator'
                        },
                        {
                            config: 'password',
                            type: 'password',
                            message: 'password:'
                        }
                    ],
                    then: function (results, done) {
                        grunt.file.write('./secrets.test.json',
                            '{\n' +
                            '    "publish": {\n' +
                            '        "host": "' + results.host + '",\n' +
                            '        "dest": "' + results.dest + '",\n' +
                            '        "username": "' + results.username + '",\n' +
                            '        "password": "' + results.password + '"\n' +
                            '    }\n' +
                            '}')
                    }
                }
            },
            prod_credentials: {
                options: {
                    questions: [
                        {
                            config: 'host',
                            type: 'input',
                            message: 'network folder:',
                            default: '\\\\gl-webapp01\\d$'
                        },
                        {
                            config: 'dest',
                            type: 'input',
                            message: 'destination folder :',
                            default: '\\Web\\'
                        },
                        {
                            config: 'username',
                            type: 'input',
                            message: 'username:',
                            default: 'gl-webapp01\\administrator'
                        },
                        {
                            config: 'password',
                            type: 'password',
                            message: 'password:'
                        }
                    ],
                    then: function (results, done) {
                        grunt.file.write('./secrets.prod.json',
                            '{\n' +
                            '    "publish": {\n' +
                            '        "host": "' + results.host + '",\n' +
                            '        "dest": "' + results.dest + '",\n' +
                            '        "username": "' + results.username + '",\n' +
                            '        "password": "' + results.password + '"\n' +
                            '    }\n' +
                            '}')
                    }
                }
            }
        },

        'network-credential': {
            test_credentials: {
                file: './secrets.test.json'
            },

            prod_credentials: {
                file: './secrets.prod.json'
            }
        },

        'useminPrepare': {
            html: 'src/index.html',
            options: {
                root: 'src',
                dest: '<%= distributionBuild %>'
            }
        },

        uglify: {
            generated: {
                options: {
                    sourceMap: true,
                    sourceRoot: ".<%= developmentSrc %>"
                }
            }
        },

        'filerev': {
            options: {
                algorithm: 'md5',
                length: 8,
            },
            images: {
                src: [
                    '<%= distributionBuild %>/**/*',
                    '!<%= distributionBuild %>/index.html',
                    '!<%= distributionBuild %>/fonts/**/*',
                    '!<%= distributionBuild %>/**/*.map',
                    '!<%= distributionBuild %>/assets/**/*',
                    '!<%= distributionBuild %>/web.config'
                ]
            }
        },

        'usemin': {
            html: '<%= distributionBuild %>/index.html'
        }
    });

    grunt.registerTask('install-tsd', ['shell:tsd_install']);
    grunt.registerTask('api-generator', ['gl_swagger_codegen:qsadocs_test']);
    //Dev
    grunt.registerTask('ide-pre-build', ['ngtemplates', 'clean:gui-common-asset', 'copy:gui-common-asset-to-src']);
    grunt.registerTask('build-env-dev', ['json_generator', 'json:dev_environment']);
    grunt.registerTask('build-dist', [
        'clean:dist',
        'clean:temp',
        'ide-pre-build',
        'useminPrepare',
        'copy:build-dist',
        'concat:generated',
        'cssmin:generated',
        'uglify:generated',
        'filerev',
        'usemin'
    ]);
    //Test 
    //  runt.registerTask('credentials-test', ['prompt:test_credentials']);
    grunt.registerTask('build-env-test', ['json_generator', 'json:test_environment']);
    grunt.registerTask('build-test', ['clean:build', 'build-env-test']);
    grunt.registerTask('T1_deploy-test', ['build-test', 'concat', 'ngtemplates', 'copy:build', 'uglify:build', 'cssmin:build', 'htmlbuild', 'hashres']);
    grunt.registerTask('T2_publish_test', ['network-credential:test_credentials', 'shell:echo_net_use', 'shell:net_use', 'prompt:clean_deployPath', 'clean:deployPath', 'copy:publishTest', 'shell:net_use_delete']);
    //Produzione
    grunt.registerTask('build-env-prod', ['json_generator', 'json:prod_environment']);
    grunt.registerTask('build-prod', ['clean:build', 'build-env-prod']);
    grunt.registerTask('P1_deploy-prod', ['build-prod', 'concat', 'ngtemplates', 'copy:build', 'uglify:build', 'cssmin:build', 'htmlbuild', 'hashres']);
    grunt.registerTask('P2_publish_prod', ['network-credential:prod_credentials', 'shell:net_use', 'prompt:clean_deployPath', 'clean:deployPath', 'copy:publishProd', 'shell:net_use_delete']);
}