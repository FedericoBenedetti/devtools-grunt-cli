﻿namespace App.Application.Config {
    import SecurityModule = GuiCommon.GlSecurityModule;

    // Configure the routes and route resolvers
    class RouteConfiguratorConfigBlock {

        constructor(
            private $routeProvider: ng.route.IRouteProvider,
            private routes: Array<GuiCommon.GlSecurityModule.RouteConfigElement>,
            private glRouteAuthServiceProvider: SecurityModule.IGlRouteAuthServiceProvider,
            private glUiAuthServiceProvider: SecurityModule.IGlUiAuthServiceProvider
        ) {
            glRouteAuthServiceProvider.configRoutes(routes);
            routes.forEach((r) => {

                $routeProvider.when(r.url, r.config);
            });
            //$routeProvider.when("/documento/35934920-96e3-4813-bf21-7a7d0547be49", { redirectTo: "blob:http://localhost:51555/35934920-96e3-4813-bf21-7a7d0547be49" });
            $routeProvider.otherwise({ redirectTo: '/' });
        }
    }

    // Define the routes 

    // "documento/35934920-96e3-4813-bf21-7a7d0547be49"
    // "blob:http://localhost:51555/35934920-96e3-4813-bf21-7a7d0547be49"

    class RouteConfigFactory {

        public static getRoutes(): Array<GuiCommon.GlSecurityModule.RouteConfigElement> {
            return [
                {
                    url: '/',
                    config: {
                        title: 'sample',
                        templateUrl: 'app/ui/app-pages/sample-page/sample-page.html',
                        settings: {
                            nav: 2,
                            //Style : Icon Menu http://fortawesome.github.io/Font-Awesome/icons/
                            content: 'SIDEBAR_HOME',
                            icon: '<i class="fa fa-lock"></i>'
                        }
                    },
                    authorization: {
                        isLoginRoute: true,
                        isUnauthorizedRoute: true,
                        loginRequired: false,
                        roles: []
                    }
                }
            ];
        }
    }

    // Collect the routes
    angular.module('app')
        .constant('routes', RouteConfigFactory.getRoutes())
        .config(['$routeProvider', 'routes', 'glRouteAuthServiceProvider', 'glUiAuthServiceProvider', RouteConfiguratorConfigBlock]);
}