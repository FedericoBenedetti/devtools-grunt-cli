﻿namespace App.Controllers {

    import AbstractController = App.Common.Controllers.AbstractController
    import ICommonService = App.Common.ICommonService;

    class SamplePageController extends AbstractController {

        public static $inject = ['common']

        constructor(
            common: ICommonService     
        ) {
            super(common);

            this.init();
        }

        private init() {
            this.activate('Sample Controller',[]);
        }
    }

    angular.module('app')
        .controller('sample-page-controller', SamplePageController);
}